#include "dialog.h"
#include "ui_dialog.h"
#include "commonfunc.h"
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv_modules.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core.hpp>
#include "opencv2/features2d.hpp"
#include "opencv2/xfeatures2d.hpp"
#include "opencv2/highgui.hpp"
using namespace cv;
using namespace cv::xfeatures2d;

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{   cv::Mat colorImg = cv::imread("../3D_93/kinect_data/rgb/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
    commonFunc imgProcessing;
    std::vector<cv::KeyPoint> keyPts; keyPts.clear();
    imgProcessing.featureExtraction(colorImg, keyPts);
    imgProcessing.showKeyPoints(colorImg, keyPts);


}

void Dialog::on_pushButton_2_clicked()
{   commonFunc imgProcessing;
    cv::Mat colorImg = cv::imread("../3D_93/kinect_data/rgb/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
    // Load second image for feature matching examples
    cv::Mat depthMap_2 = cv::imread("../3D_93/kinect_data/depth/frame_02.png", CV_LOAD_IMAGE_UNCHANGED);
    cv::Mat colorImg_2 = cv::imread("../3D_93/kinect_data/rgb/frame_02.png", CV_LOAD_IMAGE_UNCHANGED);
    cv::Mat new_rgb_1;
    cv::Mat new_rgb_2;
    cv::cvtColor(colorImg, new_rgb_1, cv::COLOR_RGBA2RGB);
    cv::cvtColor(colorImg_2, new_rgb_2, cv::COLOR_RGBA2RGB);
    imgProcessing.flipImage(new_rgb_2);
    imgProcessing.flipImage(depthMap_2);

    std::vector<cv::KeyPoint> keyPts_1, keyPts_2; keyPts_1.clear(); keyPts_2.clear();
    std::vector< cv::DMatch > *matches = new std::vector< cv::DMatch >;
    imgProcessing.featureMatching(new_rgb_1, keyPts_1, new_rgb_2, keyPts_2, matches);


    // If feature matches found, show them.
    if(matches->size()>0)
      {
        std::cout<<"matches number "<<matches->size()<<std::endl;
        // Show feature matches

      }

    // Remove outlier matches
    bool robustMatch = true; matches->clear();
    imgProcessing.featureMatching(new_rgb_1, keyPts_1, new_rgb_2, keyPts_2, matches, robustMatch);

    // If feature matches found, show them.
    if(matches->size()>0)
      {
        std::cout<<"matches number "<<matches->size()<<std::endl;
        // Show feature matches
        imgProcessing.showFeatureMatches(new_rgb_1, keyPts_1, new_rgb_2, keyPts_2, matches);
      }
}

void Dialog::on_pushButton_3_clicked()
{
     cv::Mat new_rgb_1;
     cv::Mat depthMap = cv::imread("../3D_93/kinect_data/depth/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
     cv::Mat colorImg = cv::imread("../3D_93/kinect_data/rgb/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
     cv::cvtColor(colorImg, new_rgb_1, cv::COLOR_RGBA2RGB);
     commonFunc imgProcessing;
     imgProcessing.rgbd2pointcloud(new_rgb_1, depthMap);
}

void Dialog::on_pushButton_4_clicked()
{
    commonFunc image;
    image.visualizepcl();
}
