#include <pcl/visualization/cloud_viewer.h>
#include <iostream>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>


void visualizepcl()
{
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::io::loadPCDFile ("RGBColor.pcd", *cloud);

    pcl::visualization::CloudViewer viewer("Cloud Viewer");


    viewer.showCloud(cloud);

    while (!viewer.wasStopped ())
    {
    }
    return 0;
}
