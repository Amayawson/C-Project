#include "commonfunc.h"
#include <pcl/visualization/cloud_viewer.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv_modules.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core.hpp>

#include "opencv2/features2d.hpp"
#include "opencv2/xfeatures2d.hpp"
#include "opencv2/highgui.hpp"
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
using namespace cv;
using namespace cv::xfeatures2d;

// Feature detection function headers


#include <iostream>
#include <fstream>
commonFunc::commonFunc()
{
}

void commonFunc::dispDepthColor(cv::Mat &depthMap, cv::Mat &depthColor)
{
  double min;
  double max;

  // Get minimum and maximum values
  cv::minMaxIdx(depthMap, &min, &max);

  // Histogram Equalization
  cv::Mat adjMap;
  float scale = 255 / (max-min);
  depthMap.convertTo(adjMap,CV_8UC1, scale, -min*scale);

  // Convert to color map display
  cv::applyColorMap(adjMap, depthColor, cv::COLORMAP_JET);
}

void commonFunc::dispDepthGray(cv::Mat &depthMap, cv::Mat &depthGray)
{
  // normalize depth map to uint8 values
  cv::normalize(depthMap, depthGray, 0, 255, CV_MINMAX);
  depthGray.convertTo(depthGray, CV_8UC3);
}

// Convert color image to gray scale image
void commonFunc::rgb2gray(cv::Mat &rgbImg, cv::Mat &grayImg)
{
  cv::cvtColor(rgbImg, grayImg, cv::COLOR_RGB2GRAY);
}
// Flip image left to right
void commonFunc::flipImage(cv::Mat &rgbImg)
{
  cv::flip(rgbImg, rgbImg, 1);
}

void commonFunc::featureExtraction
(cv::Mat &rgbImg, std::vector<cv::KeyPoint> &keyPts) {

//-- Step 1: Detect the keypoints using SURF Detector
  int minHessian = 400;

  Ptr<SURF> detector = SURF::create( minHessian );
  cv::Mat grayImg;
  rgb2gray(rgbImg, grayImg);
  detector->detect( grayImg, keyPts );
}


// Show detected keypoints on the color image
void commonFunc::showKeyPoints
(cv::Mat &rgbImg, std::vector<cv::KeyPoint> &keyPts){
  //-- Draw keypoints
    cv::Mat img_keyPts;
    cv::Mat onlyrgb;
    cv::cvtColor(rgbImg, onlyrgb, cv::COLOR_RGBA2RGB);
    drawKeypoints( onlyrgb, keyPts, img_keyPts, cv::Scalar::all(-1), cv::DrawMatchesFlags::DRAW_RICH_KEYPOINTS );
  //-- Show detected (drawn) keypoints
  cv::namedWindow("Keypoints", CV_WINDOW_NORMAL);
  cv::imshow("Keypoints", img_keyPts );

  std::cout<<"End feature detection...\n";
}



////////////////////////////////////////////////////////////////
///////////// Image feature detection and matching /////////////
////////////////////////////////////////////////////////////////

// Detect and match features between two images
void commonFunc::featureMatching
(cv::Mat &rgb_1, std::vector<cv::KeyPoint> &keyPts_1,
 cv::Mat &rgb_2, std::vector<cv::KeyPoint> &keyPts_2,
 std::vector< cv::DMatch > *matches, bool robustMatch)
{
  std::cout<<"Start feature matching...\n";
    //-- Extract SURF features

    int minHessian = 400;

    Ptr<SURF> detector = SURF::create( minHessian );

    cv::Mat gray_1; rgb2gray(rgb_1, gray_1);
    cv::Mat gray_2; rgb2gray(rgb_2, gray_2);

    detector->detect(gray_1, keyPts_1);
    detector->detect(gray_2, keyPts_2);

  //-- Draw keypoints
  cv::Mat img_keyPts_1;
  cv::Mat img_keyPts_2;
  cv::Mat new_rgb_1;
  cv::Mat new_rgb_2;
  cv::cvtColor(rgb_1, new_rgb_1, cv::COLOR_RGBA2RGB);
  cv::cvtColor(rgb_2, new_rgb_2, cv::COLOR_RGBA2RGB);

  drawKeypoints( new_rgb_1, keyPts_1, img_keyPts_1, cv::Scalar::all(-1), cv::DrawMatchesFlags::DEFAULT );
  drawKeypoints( new_rgb_2, keyPts_2, img_keyPts_2, cv::Scalar::all(-1), cv::DrawMatchesFlags::DEFAULT );

  //-- Compute descriptor
  Ptr<SURF> extractor = SURF::create();

  cv::Mat descriptors_1, descriptors_2;
  extractor->detectAndCompute( gray_1, Mat(), keyPts_1, descriptors_1 );
  extractor->detectAndCompute( gray_2, Mat(), keyPts_2, descriptors_2 );
  std::cout<<"descriptors type: "<<descriptors_1.type()<<std::endl;

  //-- Feature matching using descriptors
  cv::FlannBasedMatcher matcher;
  matcher.match( descriptors_1, descriptors_2, *matches );

  std::cout<<"Matched descriptors: "<<matches->size()<<std::endl;

  if(robustMatch)
    {
      std::cout<<"\n Start outlier removal...\n";
      double max_dist = 0; double min_dist = 10000;
      //-- Quick calculation of max and min distances between keypoints
      for( int i = 0; i < descriptors_1.rows; i++ )
        { double dist = (*matches)[i].distance;
          if( dist < min_dist ) min_dist = dist;
          if( dist > max_dist ) max_dist = dist;
        }
      std::cout<<"max descriptor distance = "<<max_dist<<", min descriptor disance = " <<min_dist<<std::endl;
      // Only consider matches with small distances
      std::vector< cv::DMatch > good_matches;
      for( int i = 0; i < descriptors_1.rows; i++ )
        { if( (*matches)[i].distance <= cv::max(2*min_dist, 0.02) )
            { good_matches.push_back( (*matches)[i]); }
        }

      // Overwrite with the good matches.
      matches->clear();
      for(int i = 0; i<good_matches.size(); i++ )
        {
          matches->push_back( good_matches[i]);
        }
      std::cout<<"Good matches number: "<<matches->size()<<std::endl;
    }
  std::cout<<"End feature matching...\n";
}

// Draw the feature matches
void commonFunc::showFeatureMatches
(cv::Mat &rgb_1, std::vector<cv::KeyPoint> &keyPts_1,
 cv::Mat &rgb_2, std::vector<cv::KeyPoint> &keyPts_2,
 std::vector< cv::DMatch > *matches)
{
  //-- Show detected (drawn) matches
  cv::Mat img_matches;
  cv::drawMatches( rgb_1, keyPts_1, rgb_2, keyPts_2,
                   *matches, img_matches, cv::Scalar::all(-1), cv::Scalar::all(-1),
                   std::vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

  //-- Show detected matches
  cv::namedWindow("Feature Matches", CV_WINDOW_NORMAL);
  imshow( "Feature Matches", img_matches );

}


////////////////////////////////////////////////////////////////
/////////// RGB-D data to 3D Point Cloud Rendering /////////////
////////////////////////////////////////////////////////////////

void commonFunc::myDepth2meter(const float feat_x, const float feat_y, const float rawDisparity,
                             float &X, float &Y, float &Z)
{
  // reject invalid points
  if(rawDisparity <= 0)
    {
      X = 0; Y = 0; Z = 0; return;
    }

  float fx = 525.0; // focal length x
  float fy = 525.0; // focal length y
  float cx = 319.5; // optical center x
  float cy = 239.5; // optical center y
  float sclFactor = 5000.0;

  // Recall the camera projective projection model
  Z = rawDisparity / sclFactor;
  X = (feat_x - cx) * Z / fx;
  Y = (feat_y - cy) * Z / fy;
}

// https://openkinect.org/wiki/Imaging_Information
// minDistance = -10
// scaleFactor = .0021.
// These values were found by hand.
void commonFunc::depth2meter(const float feat_x, const float feat_y, const float rawDisparity,
                             float &X, float &Y, float &Z)
{
  float minDistance = -10;
  float scaleFactor = 0.0021;
  Z = 0.1236 * std::tan(rawDisparity / 2842.5 + 1.1863);
  X = (feat_x - 480 / 2) * (Z + minDistance) * scaleFactor;
  Y = (feat_y - 640 / 2) * (Z + minDistance) * scaleFactor;
}

// Convert rgb + depth images to colored point clouds
void commonFunc::rgbd2pointcloud(const cv::Mat &rgbImg, const cv::Mat &depthImg)
{


      pcl::PointCloud<pcl::PointXYZRGB> cloud1;
      cloud1.width    = depthImg.rows;
      cloud1.height   = depthImg.cols;
      cloud1.is_dense = false;
      cloud1.points.resize (cloud1.width * cloud1.height);
      int p=0;
      for(int i=0; i<depthImg.rows; i++) // x
        {
          for(int j=0; j<depthImg.cols; j++) // y
            {
              float X, Y, Z;
              unsigned short depth = depthImg.at<unsigned short>(i, j);
              // Render the 3D values
              myDepth2meter(i,j,depth, X, Y, Z);

              // Remove features which are out of Kinect senser range
              if(X>5 || Y > 5 || Z == 0.0){continue; }
              // Write out the colored 3D point
              cloud1.points[p].x = X;
              cloud1.points[p].y = Y;
              cloud1.points[p].z = Z;
              cloud1.points[p].r = (float)rgbImg.at<cv::Vec3b>(i,j)[0];
              cloud1.points[p].g = (float)rgbImg.at<cv::Vec3b>(i,j)[1];
              cloud1.points[p].b = (float)rgbImg.at<cv::Vec3b>(i,j)[2];
              p++;


            }
        }
        pcl::io::savePCDFileASCII ("RGBColor.pcd",cloud1 );
    }

void commonFunc::visualizepcl(){
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::io::loadPCDFile ("RGBColor.pcd", *cloud);

    pcl::visualization::CloudViewer viewer("Cloud Viewer");


    viewer.showCloud(cloud);

    while (!viewer.wasStopped ())
    {
    }

}

