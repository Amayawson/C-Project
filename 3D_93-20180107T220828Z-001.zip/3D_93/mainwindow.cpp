#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/opencv_modules.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core.hpp>
#include <stdio.h>
#include "dialog.h"
#include "commonfunc.h"
#include "kinect_rgbd_grabber.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_3_clicked()
{

   Dialog dialog2;
   dialog2.setModal(true);
   dialog2.exec();


}

void MainWindow::on_pushButton_4_clicked()
{
    cv::Mat depthMap = cv::imread("../3D_93/kinect_data/depth/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);

    cv::Mat depthGray;

    commonFunc::static_dispDepthGray(depthMap, depthGray);
    cv::namedWindow("depthGray", CV_WINDOW_AUTOSIZE);
    cv::imshow("depthGray", depthGray);
}

void MainWindow::on_pushButton_5_clicked()
{
    cv::Mat colorImg = cv::imread("../3D_93/kinect_data/rgb/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
    cv::namedWindow("imgColor", CV_WINDOW_NORMAL);
    cv::imshow("imgColor", colorImg);
}

void MainWindow::on_pushButton_2_clicked()
{
     cv::Mat depthMap = cv::imread("../3D_93/kinect_data/depth/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
}

void MainWindow::on_pushButton_clicked()
{
  cv::Mat colorImg = cv::imread("../3D_93/kinect_data/rgb/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
}

void MainWindow::on_pushButton_6_clicked()
{
    cv::Mat depthMap = cv::imread("../3D_93/kinect_data/depth/frame_01.png", CV_LOAD_IMAGE_UNCHANGED);
    cv::Mat depthGray;
    cv::Mat depthColor;
    commonFunc::static_dispDepthGray(depthMap, depthGray);
    commonFunc imgProcessing;
    imgProcessing.dispDepthColor(depthMap, depthColor);
    // Display depth image using Color scale
    cv::namedWindow("depthColor", CV_WINDOW_NORMAL);
    cv::imshow("depthColor", depthColor);

}

void MainWindow::on_pushButton_7_clicked()
{   int frame_delay_ = 1000;
    Kinect_RGBD_Grabber app;


    while(1){
        cv::imshow("Color", app.GetColorFrame());
        cv::imshow("Depth", app.GetDepthFrame());
        cv::imshow("Depth Mod", app.ModDepthForDisplay(app.GetDepthFrame()));
        cv::waitKey(frame_delay_);

}

}
