//*Author: ROGER PI ROIG u1926981@gmail.com *//
// Free to use but keep author information //

#include <Kinect.h>
#include <stdexcept>
#include <iostream>
#include <thread>
#include <chrono>
#include <opencv2/opencv.hpp>

#ifndef KINECT_RGBD_GRABBER_H
#define KINECT_RGBD_GRABBER_H

// Safe release for Windows interfaces
template<class Interface>
inline void SafeRelease(Interface*& ptr_int)
{
    if (ptr_int)
    {
        ptr_int->Release();
        ptr_int = nullptr;
    }
}


class Kinect_RGBD_Grabber
{
public:
    Kinect_RGBD_Grabber();

    ~Kinect_RGBD_Grabber();

    cv::Mat GetDepthFrame();

    cv::Mat GetColorFrame();

    cv::Mat ModDepthForDisplay(const cv::Mat& mat);

private:

    void InitDepthSource();

    void InitColorSource();

    IDepthFrame* WaitForDepthFrame();

    IColorFrame* WaitForColorFrame();

    void ShowDepthFrame();

    void ShowColorFrame();


    static const int depth_w_ = 512;  //512
    static const int depth_h_ = 424;  //424
    static const int color_w_ = 1920; //1920
    static const int color_h_ = 1080; //1080

    IKinectSensor* kin_sensor_;
    IDepthFrameReader* depth_frame_reader_;
    IColorFrameReader* color_frame_reader_;



};


#endif // KINECT_RGBD_GRABBER_H
